

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Data Wisata</h1>

<div class="card shadow mb-4">
    <div class="card-body">
        <a href="<?php echo e(route('dashboard.tambah')); ?>" class="btn btn-primary mb-3">+ Tambah Wisata</a>

        <div class="table-responsive">
            <table class="table table-bordered" width="100%" cellspacing="0">
                <thead class="bg-primary text-white">
                    <tr>
                        <th>ID</th>
                        <th>Nama</th>
                        <th>Gambar</th>
                        <th>Kategori</th>
                        <th>Alamat (Google Maps)</th>
                        <th>Sejarah</th>
                        <th>Jam Buka</th>
                        <th>Fasilitas</th>
                        <th>Kontak</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($d->id_destinasi); ?></td>
                        <td><?php echo e($d->nama); ?></td>
                        <td>
                            <?php if($d->gambar): ?>
                                <img src="<?php echo e(asset('uploads/' . $d->gambar)); ?>" width="100">
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($d->kategori); ?></td>
                        <td><a href="<?php echo e($d->alamat); ?>" target="_blank">Lihat Lokasi</a></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($d->sejarah, 100)); ?></td>
                        <td><?php echo e($d->jam_buka); ?></td>
                        <td><?php echo e($d->fasilitas); ?></td>
                        <td><?php echo e($d->kontak); ?></td>
                        <td>
                            <!-- Tombol Modal Edit -->
                            <button type="button" class="btn btn-sm btn-warning mb-1"
                                    data-toggle="modal" data-target="#editModal<?php echo e($d->id_destinasi); ?>">
                                <i class="fas fa-edit"></i> Edit
                            </button>

                            <!-- Form Hapus -->
                            <form action="<?php echo e(route('dashboard.hapus', $d->id_destinasi)); ?>" method="POST"
                                  onsubmit="return confirm('Yakin ingin menghapus data ini?');"
                                  style="display:inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i> Hapus
                                </button>
                            </form>
                        </td>
                    </tr>

                    <!-- Modal Edit -->
                    <div class="modal fade" id="editModal<?php echo e($d->id_destinasi); ?>" tabindex="-1"
                         role="dialog" aria-labelledby="editModalLabel<?php echo e($d->id_destinasi); ?>" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <form action="<?php echo e(route('dashboard.update', $d->id_destinasi)); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="editModalLabel<?php echo e($d->id_destinasi); ?>">Edit Data Wisata</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body row">
                                        <div class="mb-3 col-md-6">
                                            <label>Nama</label>
                                            <input type="text" name="nama" class="form-control" value="<?php echo e($d->nama); ?>" required>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label>Kategori</label>
                                            <select name="kategori" class="form-control" required>
                                                <option value="Objek Wisata Religi" <?php echo e($d->kategori == 'Objek Wisata Religi' ? 'selected' : ''); ?>>Objek Wisata Religi</option>
                                                <option value="Objek Wisata Mangrove" <?php echo e($d->kategori == 'Objek Wisata Mangrove' ? 'selected' : ''); ?>>Objek Wisata Mangrove</option>
                                                <option value="Objek Wisata Sejarah" <?php echo e($d->kategori == 'Objek Wisata Sejarah' ? 'selected' : ''); ?>>Objek Wisata Sejarah</option>
                                            </select>
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label>Alamat (Google Maps)</label>
                                            <input type="text" name="alamat" class="form-control" value="<?php echo e($d->alamat); ?>">
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label>Jam Buka</label>
                                            <input type="text" name="jam_buka" class="form-control" value="<?php echo e($d->jam_buka); ?>">
                                        </div>
                                        <div class="mb-3 col-md-12">
                                            <label>Sejarah</label>
                                            <textarea name="sejarah" class="form-control"><?php echo e($d->sejarah); ?></textarea>
                                        </div>
                                        <div class="mb-3 col-md-12">
                                            <label>Fasilitas</label>
                                            <input type="text" name="fasilitas" class="form-control" value="<?php echo e($d->fasilitas); ?>">
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label>Kontak</label>
                                            <input type="text" name="kontak" class="form-control" value="<?php echo e($d->kontak); ?>">
                                        </div>
                                        <div class="mb-3 col-md-6">
                                            <label>Gambar (kosongkan jika tidak diubah)</label>
                                            <input type="file" name="gambar" class="form-control">
                                            <?php if($d->gambar): ?>
                                                <img src="<?php echo e(asset('uploads/' . $d->gambar)); ?>" width="100" class="mt-2">
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-success">Simpan</button>
                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\destinasi\resources\views/dashboard/tampil.blade.php ENDPATH**/ ?>