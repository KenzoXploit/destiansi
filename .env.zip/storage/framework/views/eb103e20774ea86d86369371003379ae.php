

<?php $__env->startSection('content'); ?>
<div class="text-center mt-5">
    <img src="<?php echo e(asset('img/logo_banyumas.png')); ?>" alt="Logo Banyumas" style="width: 120px; height: 120px;" class="mb-3">

    <h3 class="text-secondary fw-bold">PARIWISATA PROVINSI SULAWESI SELATAN</h3>

    <a href="/" class="btn btn-primary mt-4">Lihat Web</a>

    <footer class="mt-5 text-muted">
        <small>COPYRIGHT © PARIWISATA SULSEL 2025</small>
    </footer>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\laragon\www\destinasi\resources\views/dashboard/home.blade.php ENDPATH**/ ?>