<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Wisata - <?php echo e($data->nama); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://images.unsplash.com/photo-1505228395891-9a51e7e86bf6?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            height: 50vh;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            margin-bottom: 30px;
        }
        .detail-image {
            display: block;
            max-width: 100%;
            height: auto;
            object-fit: cover;
            border-radius: 10px;
            margin: 0 auto 30px auto;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }
        .info-section {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 30px;
            margin-bottom: 30px;
        }
        .info-title {
            font-size: 1.8rem;
            font-weight: bold;
            margin-bottom: 20px;
            color: #343a40;
            border-bottom: 3px solid #0d6efd;
            padding-bottom: 10px;
        }
        .info-list {
            list-style-type: none;
            padding-left: 0;
        }
        .info-list li {
            margin-bottom: 15px;
            font-size: 1.1rem;
        }
        .info-list strong {
            display: block;
            color: #0d6efd;
            margin-bottom: 5px;
        }
        footer {
            background-color: #343a40;
            color: white;
            padding: 30px 0;
            margin-top: 50px;
        }
        .map-container {
            height: 400px;
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="/beranda">WISATA PALOPO</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/beranda">BERANDA</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="wisataDropdown" role="button" data-bs-toggle="dropdown">
                            OBJEK WISATA
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="/kategori/wisatareligi">Objek Wisata Religi</a></li>
                            <li><a class="dropdown-item" href="/kategori/wisatamangrove">Objek Wisata Mangrove</a></li>
                            <li><a class="dropdown-item" href="/kategori/wisatasejarah">Objek Wisata Sejarah</a></li>
                        </ul>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="/login" class="btn btn-outline-light">LOGIN</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section">
        <div>
            <h1 class="display-4"><?php echo e($data->nama); ?></h1>
            <p class="lead"><?php echo e($data->kategori); ?></p>
        </div>
    </div>

    <!-- Detail Content -->
    <div class="container">
        <!-- Gambar -->
        <img src="<?php echo e(asset('uploads/' . $data->gambar)); ?>" class="detail-image" alt="<?php echo e($data->nama); ?>">

        <div class="row">
            <div class="col-md-8">
                <div class="info-section">
                    <h2 class="info-title">Informasi Wisata</h2>

                    <div class="mb-4">
                        <ul class="info-list">
                            <li><strong>Nama</strong><?php echo e($data->nama); ?></li>
                            <li><strong>Kategori</strong><?php echo e($data->kategori); ?></li>
                            <li><strong>Alamat</strong></li>
                        </ul>
                    </div>
                    <div class="map-container">
                        <iframe src="<?php echo e($data->alamat); ?>" width="100%" height="100%" style="border:0;" allowfullscreen loading="lazy"></iframe>
                    </div>

                    <div class="mb-4">
                        <h4>Sejarah</h4>
                        <p><?php echo nl2br(e($data->sejarah)); ?></p>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="info-section">
                    <h2 class="info-title">Informasi Tambahan</h2>
                    <ul class="info-list">
                        <li><strong>Jam Buka</strong><?php echo e($data->jam_buka); ?></li>
                        <li>
                            <strong>Fasilitas</strong>
                                <?php $__currentLoopData = explode(',', $data->fasilitas); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e(trim($item)); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                        <li><strong>Kontak</strong><?php echo e($data->kontak); ?></li>
                    </ul>

                    <div class="d-grid gap-2 mt-4">
                        <a href="<?php echo e($data->alamat); ?>" target="_blank" class="btn btn-primary">
                            <i class="fas fa-directions me-2"></i> Petunjuk Arah
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="text-center">
        <div class="container">
            <h3>WISATA RELIGI PALOPO</h3>
            <p>Temukan kedamaian spiritual di Kota Palopo</p>
            <div class="social-links mt-3">
                <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-2x"></i></a>
                <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-2x"></i></a>
                <a href="#" class="text-white"><i class="fab fa-twitter fa-2x"></i></a>
            </div>
            <p class="mt-3">&copy; 2025 Wisata Palopo. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\destinasi\resources\views/detail.blade.php ENDPATH**/ ?>