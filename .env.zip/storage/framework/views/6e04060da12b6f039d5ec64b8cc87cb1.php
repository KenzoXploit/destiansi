

<?php $__env->startSection('content'); ?>
<h1 class="h3 mb-4 text-gray-800">Dashboard Home</h1>
<p>Selamat datang di dashboard admin wisata!</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\destinasi\resources\views/dashboard/home.blade.php ENDPATH**/ ?>