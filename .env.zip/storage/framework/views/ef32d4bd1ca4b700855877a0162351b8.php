<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beranda Wisata Palopo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
        }
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('<?php echo e(asset("images/hero-bg.jpg")); ?>');
            background-size: cover;
            background-position: center;
            color: white;
            height: 90vh;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            text-align: center;
        }
        .section-title {
            font-weight: bold;
            font-size: 2.5rem;
            text-align: center;
            margin: 60px 0 20px;
        }
        .rekomendasi {
            background: linear-gradient(45deg, #3acfd5, #3a4ed5);
            padding: 60px 0;
            color: white;
        }
        .card {
            border: none;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            transition: transform 0.3s ease-in-out;
        }
        .card:hover {
            transform: translateY(-10px);
        }
        .footer {
            background-color: #212529;
            color: white;
            padding: 40px 0;
            text-align: center;
        }
        .visitor-counter {
            background-color: rgba(255, 255, 255, 0.1);
            padding: 10px 20px;
            border-radius: 10px;
            margin-top: 20px;
            font-size: 1.2rem;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="#">WISATA PALOPO</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="/beranda">BERANDA</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="wisataDropdown" role="button" data-bs-toggle="dropdown">
                            OBJEK WISATA
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="/kategori/wisatareligi">Objek Wisata Religi</a></li>
                            <li><a class="dropdown-item" href="/kategori/wistamangrove">Objek Wisata Mangrove</a></li>
                            <li><a class="dropdown-item" href="/kategori/wisatasejarah">Objek Wisata Sejarah</a></li>
                        </ul>
                    </li>
                </ul>
                <a href="/login" class="btn btn-outline-light">LOGIN</a>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
        <h1 class="display-4">WISATA YANG ADA DI PALOPO</h1>
        <p class="lead">Explore the beauty of Indonesian nature and culture</p>

        <div class="text-center text-white bg-dark py-3 mt-5">
            <h5>Total Pengunjung Website: <?php echo e($totalVisitors); ?></h5>
        </div>
    </section>

    <!-- Rekomendasi Section -->
    <section class="rekomendasi">
        <div class="container">
            <h2 class="section-title">REKOMENDASI WISATA</h2>
            <div class="row justify-content-center">
                <div class="col-md-3">
                    <div class="card text-center">
                        <img src="<?php echo e(asset('images/nusa.jpg')); ?>" class="card-img-top" alt="Nusa Lembongan">
                        <div class="card-body">
                            <h5 class="card-title">Nusa Lembongan</h5>
                            <p class="card-text"><strong>1st place</strong><br>Nusa Lembongan Island</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center">
                        <img src="<?php echo e(asset('images/ulun.jpg')); ?>" class="card-img-top" alt="Pura Ulun Danu">
                        <div class="card-body">
                            <h5 class="card-title">Pura Ulun Bedugul Bali</h5>
                            <p class="card-text"><strong>2nd place</strong><br>Pura ulun bedugul Bali</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center">
                        <img src="<?php echo e(asset('images/rajaampat.jpg')); ?>" class="card-img-top" alt="Raja Ampat">
                        <div class="card-body">
                            <h5 class="card-title">Piyanemo Raja Ampat</h5>
                            <p class="card-text"><strong>3rd place</strong><br>Piyanemo raja Ampat</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-center">
                        <img src="<?php echo e(asset('images/kelimutu.jpg')); ?>" class="card-img-top" alt="Gunung Kelimutu">
                        <div class="card-body">
                            <h5 class="card-title">Gunung Kelimutu</h5>
                            <p class="card-text"><strong>4th place</strong><br>Gunung Kelimutu</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <p>TRAVEL AND ENJOY YOUR HOLIDAY</p>
        <p>choose your fun holiday</p>
        <div class="social-icons mb-3">
            <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-2x"></i></a>
            <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-2x"></i></a>
            <a href="#" class="text-white"><i class="fab fa-twitter fa-2x"></i></a>
        </div>
        <p>&copy; <?php echo e(date('Y')); ?> Wisata Palopo. All Rights Reserved.</p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\destinasi\resources\views/beranda.blade.php ENDPATH**/ ?>