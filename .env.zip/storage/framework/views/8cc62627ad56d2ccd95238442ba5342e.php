<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wisata Mangrove Palopo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .navbar-brand {
            font-weight: bold;
            font-size: 1.5rem;
        }

        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url("<?php echo e(asset('images/mangrove-bg.jpg')); ?>");
            background-size: cover;
            background-position: center;
            height: 50vh;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            margin-bottom: 50px;
        }

        .wisata-card {
            transition: transform 0.3s;
            margin-bottom: 30px;
            border: none;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .wisata-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0,0,0,0.2);
        }

        .wisata-img {
            height: 250px;
            object-fit: cover;
        }

        .section-title {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 50px;
            text-align: center;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
            width: 100px;
            height: 4px;
            background: linear-gradient(to right, #198754, #0d6efd);
        }

        .eco-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            background-color: #0d6efd;
            color: white;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: bold;
        }

        footer {
            background-color: #343a40;
            color: white;
            padding: 30px 0;
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="/beranda">WISATA PALOPO</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a class="nav-link" href="/beranda">BERANDA</a></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle active" href="#" id="wisataDropdown" role="button" data-bs-toggle="dropdown">
                            OBJEK WISATA
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="/wisatareligi">Objek Wisata Religi</a></li>
                            <li><a class="dropdown-item active" href="/wistamangrove">Objek Wisata Mangrove</a></li>
                            <li><a class="dropdown-item" href="/wisatasejarah">Objek Wisata Sejarah</a></li>
                        </ul>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="/login" class="btn btn-outline-light">LOGIN</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero-section">
        <div>
            <h1 class="display-4">WISATA MANGROVE PALOPO</h1>
            <p class="lead">Jelajahi keindahan hutan mangrove dan ekosistemnya di Palopo</p>
        </div>
    </div>

    <!-- Konten Wisata Mangrove -->
    <div class="container mb-5">
        <h2 class="section-title">DESTINASI WISATA MANGROVE</h2>

        <div class="row">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->kategori === 'Objek Wisata Mangrove'): ?>
                <div class="col-md-4">
                    <div class="card wisata-card">
                        <img src="<?php echo e(asset('uploads/' . $item->gambar)); ?>" class="card-img-top wisata-img" alt="<?php echo e($item->nama); ?>">
                        <span class="eco-badge">Wisata Mangrove</span>
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($item->nama); ?></h5>
                            <p class="card-text"><?php echo e(\Illuminate\Support\Str::limit($item->sejarah, 100)); ?></p>
                            <a href="<?php echo e(route('detail.show', $item->id_destinasi)); ?>" class="btn btn-primary">Lihat Detail</a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Footer -->
    <footer class="text-center">
        <div class="container">
            <h3>WISATA MANGROVE PALOPO</h3>
            <p>Nikmati keindahan dan kesejukan alam bakau Kota Palopo</p>
            <div class="social-links mt-3">
                <a href="http://instagram.com/algzspace" class="text-white me-3"><i class="fab fa-instagram fa-2x"></i></a>
                <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-2x"></i></a>
                <a href="#" class="text-white"><i class="fab fa-twitter fa-2x"></i></a>
            </div>
            <p class="mt-3">&copy; 2023 Wisata Palopo. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\destinasi\resources\views/kategori/wisatamangrove.blade.php ENDPATH**/ ?>